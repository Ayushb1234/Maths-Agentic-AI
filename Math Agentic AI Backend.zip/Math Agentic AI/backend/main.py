from fastapi import FastAPI
from services.feedback_db import FeedbackDB
from services.routing_agent import MathRoutingAgent
from fastapi.middleware.cors import CORSMiddleware
from fastapi import Body


app = FastAPI()
db = FeedbackDB()
agent = MathRoutingAgent()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/ask")
def ask_question(data: dict = Body(...)):
    question = data.get("question")
    answer = agent.answer_question(question)
    return {"question": question, "answer": answer}

# @app.post("/ask")
# def ask_question(question: str):
#     answer = agent.answer_question(question)
#     return {"question": question, "answer": answer}

@app.get("/last-answer")
def get_last_answer():
    return {"last_answer": agent.last_answer}

@app.post("/feedback")
def give_feedback(question: str, answer: str, rating: int):
    db.save_feedback(question, answer, rating)
    return {"status": "Feedback saved successfully"}
