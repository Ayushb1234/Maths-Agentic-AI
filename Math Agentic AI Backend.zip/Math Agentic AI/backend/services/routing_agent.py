# from knowledge_base import KnowledgeBase
# from math_guardrails import MathGuardrails
# from tavily import TavilyClient
# from mcp_client import MCPClient


# class MathRoutingAgent:
#     def __init__(self):
#         # Load KB
#         self.kb = KnowledgeBase()
#         self.kb.build_kb(r"D:\programming\programming\python\age&genderdetection\Math Agentic AI\data\math_questions.txt")
#         # Guardrails
#         self.guard = MathGuardrails()
#         # Web search client
#         self.search = TavilyClient(api_key="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")  # Get free API key from Tavily

#     def answer_question(self, query):
#         # 1️⃣ Input Guardrails
#         ok, msg = self.guard.validate_input(query)
#         if not ok:
#             return msg
        
#         # 2️⃣ Check Knowledge Base
#         results = self.kb.query_kb(query)
#         if results and len(results) > 0:
#             answer = results[0].metadata["answer"]
#             ok, safe_answer = self.guard.validate_output(answer)
#             return safe_answer if ok else "⚠️ Unsafe output detected."
        
#         # 3️⃣ Fallback to Web Search
#         print("🔍 Querying web search as fallback...")
#         try:
#             search_results = self.search.search(query, max_results=1)
#             if search_results and "results" in search_results and len(search_results["results"]) > 0:
#                 snippet = search_results["results"][0]["content"]
#                 # Simulate step-by-step formatting
#                 answer = f"Based on external sources, here is the explanation:\n\n{snippet}"
#                 ok, safe_answer = self.guard.validate_output(answer)
#                 return safe_answer if ok else "⚠️ Unsafe or irrelevant content."
#             else:
#                 return "⚠️ No reliable answer found online."
#         except Exception as e:
#             return f"⚠️ Web search failed: {str(e)}"


# from services.knowledge_base import KnowledgeBase
# from services.math_guardrails import MathGuardrails
# from services.mcp_client import MCPClient

# # class MathRoutingAgent:
# #     def __init__(self):
# #         # Load Knowledge Base
# #         self.kb = KnowledgeBase()
# #         self.kb.build_kb(
# #             r"D:\programming\programming\python\age&genderdetection\Math Agentic AI\data\math_questions.txt"
# #         )
# #         # Guardrails
# #         self.guard = MathGuardrails()
# #         # MCP Client for Web Search
# #         self.mcp = MCPClient(server_url="http://localhost:5001/search_web")

# #     def answer_question(self, query):
# #         # 1️⃣ Input Guardrails
# #         ok, msg = self.guard.validate_input(query)
# #         if not ok:
# #             return msg
        
# #         # 2️⃣ Check Knowledge Base
# #         results = self.kb.query_kb(query)
# #         if results and len(results) > 0:
# #             answer = results[0].metadata["answer"]
# #             ok, safe_answer = self.guard.validate_output(answer)
# #             return safe_answer if ok else "⚠️ Unsafe output detected."
        
# #         # 3️⃣ Fallback to MCP Web Search
# #         print("🌐 Querying MCP search server as fallback...")
# #         search_context = self.mcp.search_query(query)

# #         if "No relevant data" not in search_context and "Search failed" not in search_context:
# #             # Format the web search response
# #             answer = f"Based on external sources, here is the explanation:\n\n{search_context}"
# #             ok, safe_answer = self.guard.validate_output(answer)
# #             return safe_answer if ok else "⚠️ Unsafe or irrelevant content."
# #         else:
# #             return "⚠️ No reliable answer found online."



# class MathRoutingAgent:
#     def __init__(self):
#         self.kb = KnowledgeBase()
#         self.kb.build_kb(
#             r"D:\programming\programming\python\age&genderdetection\Math Agentic AI\data\math_questions.txt"
#         )
#         self.guard = MathGuardrails()
#         self.mcp = MCPClient()
#         self.last_answer = None  # Store last answer temporarily

#     def answer_question(self, query):
#         ok, msg = self.guard.validate_input(query)
#         if not ok:
#             self.last_answer = msg
#             return msg

#         # Knowledge base search
#         results = self.kb.query_kb(query)
#         if results and len(results) > 0:
#             answer = results[0].metadata["answer"]
#             self.last_answer = answer
#             return answer

#         # MCP fallback search
#         print("🌐 Querying MCP search server...")
#         search_context = self.mcp.search_query(query)
#         if "No relevant data" not in search_context:
#             answer = f"Based on external sources:\n{search_context}"
#             self.last_answer = answer
#             return answer

#         self.last_answer = "⚠️ No reliable answer found."
#         return self.last_answer


# services/routing_agent.py
import re, ast, operator as op
from services.knowledge_base import KnowledgeBase
from services.math_guardrails import MathGuardrails
from services.mcp_client import MCPClient

# safe eval for arithmetic
OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul,
       ast.Div: op.truediv, ast.Pow: op.pow, ast.USub: op.neg, ast.UAdd: op.pos}

def _eval_ast(node):
    if isinstance(node, ast.Num):  # py<=3.7, in 3.8+ use Constant
        return node.n
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in OPS:
        return OPS[type(node.op)](_eval_ast(node.left), _eval_ast(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in OPS:
        return OPS[type(node.op)](_eval_ast(node.operand))
    raise ValueError("Unsupported expression")

def safe_eval_expr(expr: str):
    # map caret ^ to power ** (users type ^; Python uses **)
    expr = expr.replace("^", "**")
    tree = ast.parse(expr, mode="eval")
    return _eval_ast(tree.body)

def explain_two_term(expr: str) -> str:
    # simple two-term explanation e.g., "6 + 7"
    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*([+\-*/^])\s*(\d+(?:\.\d+)?)\s*", expr)
    if not m:
        return f"Compute the arithmetic expression: {expr}"
    a, op_sym, b = m.groups()
    op_name = {"+": "Add", "-": "Subtract", "*": "Multiply", "/": "Divide", "^": "Raise"}[op_sym]
    mid = {"+" : " + ", "-" : " - ", "*" : " × ", "/" : " ÷ ", "^" : "^"}[op_sym]
    return f"Step 1: {op_name} {a} and {b}.\nStep 2: {a}{mid}{b} = {safe_eval_expr(a + {'^':'**'}.get(op_sym, op_sym) + b)}"

class MathRoutingAgent:
    def __init__(self):
        self.kb = KnowledgeBase()
        self.kb.build_kb(
            r"D:\programming\programming\python\age&genderdetection\Math Agentic AI\data\math_questions.txt"
        )
        self.guard = MathGuardrails()
        self.mcp = MCPClient()
        self.last_answer = None

    def _try_direct_arithmetic(self, query: str):
        # accept expressions with digits/operators/brackets
        if re.fullmatch(r"[0-9\.\s\+\-\*/\^\(\)]+", query.strip()):
            try:
                val = safe_eval_expr(query.strip())
                steps = explain_two_term(query.strip())
                return f"{steps}\nAnswer: {val}"
            except Exception:
                # fall through to KB/search
                return None
        return None

    def answer_question(self, query):
        ok, msg = self.guard.validate_input(query)
        if not ok:
            self.last_answer = msg
            return msg

        # NEW: direct arithmetic shortcut
        direct = self._try_direct_arithmetic(query)
        if direct:
            self.last_answer = direct
            return direct

        # KB first
        results = self.kb.query_kb(query)
        if results and len(results) > 0:
            answer = results[0].metadata["answer"]
            self.last_answer = answer
            return answer

        # MCP fallback
        print("🌐 Querying MCP search server...")
        search_context = self.mcp.search_query(query)
        if "No relevant data" not in search_context and "Search failed" not in search_context:
            answer = f"Based on external sources:\n{search_context}"
            self.last_answer = answer
            return answer

        self.last_answer = "⚠️ No reliable answer found."
        return self.last_answer
