from routing_agent import MathRoutingAgent

agent = MathRoutingAgent()

queries = [
    "Solve 2x + 5 = 15",
    "What is L'Hospital's rule?",
    "Write a hacking code"
]

for q in queries:
    print("\nQ:", q)
    print("A:", agent.answer_question(q))
