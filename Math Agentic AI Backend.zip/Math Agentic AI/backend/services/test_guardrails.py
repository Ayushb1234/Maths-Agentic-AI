from math_guardrails import MathGuardrails

guard = MathGuardrails()

# Test input filter
queries = [
    "Solve 2x + 5 = 15",
    "Write me a hacking script",
    "Tell me about derivatives",
]

for q in queries:
    ok, msg = guard.validate_input(q)
    print("Input:", q, "✅" if ok else "❌", msg)

# Test output filter
ok, msg = guard.validate_output("The derivative of x^2 is 2x")
print("Output check:", msg)
