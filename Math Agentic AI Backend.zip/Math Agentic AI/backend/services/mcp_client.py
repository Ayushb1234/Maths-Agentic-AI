import requests

class MCPClient:
    def __init__(self, server_url="http://localhost:5001/search_web"):
        self.server_url = server_url

    def search_query(self, query):
        try:
            response = requests.post(self.server_url, json={"query": query})
            if response.status_code == 200:
                data = response.json()
                if "results" in data:
                    snippets = [r.get("content", "") for r in data["results"]]
                    return "\n".join(snippets)
                return "No relevant data found."
            return f"Error {response.status_code}"
        except Exception as e:
            return f"Search failed: {str(e)}"
