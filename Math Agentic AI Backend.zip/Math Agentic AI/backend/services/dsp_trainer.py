import dspy
from feedback_db import FeedbackDB

class FeedbackTrainer:
    def __init__(self):
        self.db = FeedbackDB()
        self.lm = dspy.OpenAI(model="gpt-3.5-turbo")  # or other LLM
        self.signature = dspy.Signature(
            "RefineAnswer",
            "question -> refined_answer"
        )

    def train_from_feedback(self):
        data = self.db.get_all_feedback()
        if not data:
            return "No feedback available for training."
        
        # Create training examples
        examples = []
        for q, a, r in data:
            if r < 3:  # Low-rated answers
                examples.append({"question": q, "refined_answer": "Improve answer for: " + a})
        
        if not examples:
            return "No low-rated data to train on."
        
        # Fine-tune instructions
        program = dspy.Program(self.signature, lm=self.lm)
        program = program.compile(train_data=examples)
        program.save("refined_model.dspy")
        return "DSPy training completed and model updated!"
