from fastapi import FastAPI
import requests

app = FastAPI()

@app.post("/search_web")
def search_web(query: str, max_results: int = 3):
    """Search the web and return structured results."""
    url = "https://api.tavily.com/search"
    payload = {"query": query, "max_results": max_results}
    headers = {"Authorization": "Bearer tvly-your_api_key"}

    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        return response.json()
    return {"error": "Search failed", "status": response.status_code}
