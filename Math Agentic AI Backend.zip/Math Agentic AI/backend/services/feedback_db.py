import sqlite3

class FeedbackDB:
    def __init__(self, db_path="feedback.db"):
        self.db_path = db_path
        self.create_table()

    def connect(self):
        return sqlite3.connect(self.db_path, check_same_thread=False)

    def create_table(self):
        conn = self.connect()
        query = """
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT,
            answer TEXT,
            rating INTEGER
        )
        """
        conn.execute(query)
        conn.commit()
        conn.close()

    def save_feedback(self, question, answer, rating):
        conn = self.connect()
        query = "INSERT INTO feedback (question, answer, rating) VALUES (?, ?, ?)"
        conn.execute(query, (question, answer, rating))
        conn.commit()
        conn.close()

    def get_all_feedback(self):
        conn = self.connect()
        query = "SELECT question, answer, rating FROM feedback"
        cursor = conn.execute(query)
        results = cursor.fetchall()
        conn.close()
        return results
