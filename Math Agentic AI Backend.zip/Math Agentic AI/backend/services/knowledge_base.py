from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document

class KnowledgeBase:
    def __init__(self):
        # Using free HuggingFace embedding model (no API key needed)
        self.embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        self.vectorstore = None

    def build_kb(self, data_file=r"D:\programming\programming\python\age&genderdetection\Math Agentic AI\data\math_questions.txt"):
        docs = []
        with open(data_file, "r", encoding="utf-8") as f:
            content = f.read().split("\n\n")
            for block in content:
                if "Q:" in block and "A:" in block:
                    question = block.split("Q:")[1].split("A:")[0].strip()
                    answer = block.split("A:")[1].strip()
                    docs.append(Document(page_content=question, metadata={"answer": answer}))
        
        self.vectorstore = FAISS.from_documents(docs, self.embeddings)
        print("✅ Knowledge base built successfully.")

    def query_kb(self, query, k=2):
        if not self.vectorstore:
            print("⚠️ Knowledge base not built yet.")
            return None
        results = self.vectorstore.similarity_search(query, k=k)
        return results

if __name__ == "__main__":
    kb = KnowledgeBase()
    kb.build_kb()
    
    query = "What is derivative of x squared?"
    results = kb.query_kb(query)
    
    for r in results:
        print("\n📘 Similar Question:", r.page_content)
        print("🧠 Answer:", r.metadata["answer"])
