# import re

# class MathGuardrails:
#     def __init__(self):
#         # Basic bad words list for safety check
#         self.bad_words = ["hack", "kill", "harm", "attack", "virus", "exploit"]
#         self.math_keywords = [
#     "solve", "equation", "integral", "derivative", "theorem",
#     "geometry", "probability", "algebra", "math", "calculate",
#     "function", "limit", "vector", "matrix", "rule", "hospital",
#     "logarithm", "identity", "differentiation", "integration",
#     "series", "formula", "trigonometry", "calculus", "l'hospital"
# ]


#     def validate_input(self, question):
#         """Check if input is math-related and safe."""
#         if any(bad in question.lower() for bad in self.bad_words):
#             return False, "❌ Unsafe or harmful input detected."

#         if not any(kw in question.lower() for kw in self.math_keywords):
#             return False, "❌ This system only accepts math-related questions."

#         if len(question) < 3 or len(question) > 200:
#             return False, "❌ Input length is invalid."

#         return True, question

#     def validate_output(self, response):
#         """Ensure output is safe and relevant."""
#         if any(bad in response.lower() for bad in self.bad_words):
#             return False, "⚠️ Unsafe content in response."

#         if len(response.strip()) == 0:
#             return False, "⚠️ Empty or irrelevant response."

#         return True, response

# services/math_guardrails.py
import re

class MathGuardrails:
    def __init__(self):
        self.bad_words = ["hack", "kill", "harm", "attack", "virus", "exploit"]

    def _is_math_related(self, question: str) -> bool:
        q = question.lower().strip()

        # 1) Accept arithmetic-like expressions e.g., "6+7", "12 / 3", "(2+3)*4", "2^5"
        # numbers, (), whitespace and + - * / ^ .
        if re.fullmatch(r"[0-9\.\s\+\-\*/\^\(\)]+", q):
            return True

        # 2) Accept typical math keywords as before
        keywords = [
            "solve","equation","integral","derivative","limit","algebra","geometry",
            "trigonometry","probability","matrix","vector","series","sum","addition",
            "subtract","multiply","divide","percentage","factorial","permutation",
            "combination","l'hospital","hospital","rule","gcd","lcm","root","power"
        ]
        return any(k in q for k in keywords)

    def validate_input(self, question: str):
        q = question or ""
        # unsafe filter
        if any(bad in q.lower() for bad in self.bad_words):
            return False, "❌ Unsafe or harmful input detected."

        # loosened math filter
        if not self._is_math_related(q):
            return False, "❌ This system only accepts math-related questions."

        # reasonable length check
        if len(q) < 1 or len(q) > 500:
            return False, "❌ Input length is invalid."

        return True, question

    def validate_output(self, response: str):
        if not response or not response.strip():
            return False, "⚠️ Empty or irrelevant response."
        if any(bad in response.lower() for bad in self.bad_words):
            return False, "⚠️ Unsafe content in response."
        return True, response
