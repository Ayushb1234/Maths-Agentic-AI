import { useState } from 'react';
import axios from 'axios';

export default function AskQuestion() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [rating, setRating] = useState(null);

  const askQuestion = async () => {
  try {
    const res = await axios.post('http://localhost:8000/ask', {
      question: question
    });
    setAnswer(res.data.answer);
  } catch (err) {
    setAnswer('❌ Failed to get answer from backend.');
  }
};

  const sendFeedback = async (value) => {
    try {
      setRating(value);
      await axios.post('http://localhost:8000/feedback', null, {
        params: { question, answer, rating: value },
      });
      alert('✅ Feedback submitted!');
    } catch (err) {
      alert('❌ Feedback submission failed.');
    }
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h1>📘 Math Assistant</h1>
      <input
        type="text"
        placeholder="Ask a math question"
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        style={{ width: '60%', padding: '0.5rem' }}
      />
      <button onClick={askQuestion} style={{ marginLeft: '1rem' }}>
        Ask
      </button>

      {answer && (
        <div style={{ marginTop: '2rem' }}>
          <h3>📎 Answer:</h3>
          <p>{answer}</p>

          <h4>🧠 Was this answer helpful?</h4>
          <button onClick={() => sendFeedback(5)}>👍 Yes</button>
          <button onClick={() => sendFeedback(1)} style={{ marginLeft: '1rem' }}>
            👎 No
          </button>
        </div>
      )}
    </div>
  );
}
