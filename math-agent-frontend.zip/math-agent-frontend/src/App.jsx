import AskQuestion from './components/AskQuestion';

function App() {
  return (
    <div className="App">
      <AskQuestion />
    </div>
  );
}

export default App;
